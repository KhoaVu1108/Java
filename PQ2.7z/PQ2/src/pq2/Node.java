
package pq2;

public class Node {
    String data;
    Node left;
    Node right;

    Node(String data) {
        this.data = data;
        right = null;
        left = null;
    }
}
